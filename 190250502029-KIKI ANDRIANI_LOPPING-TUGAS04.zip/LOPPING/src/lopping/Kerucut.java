/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lopping;

/**
 *
 * @author kiki
 */
public class Kerucut {
      private int jari ;
    private int tinggi ;
    
    public void setjari (int jari)
    {
        this.jari = jari ;
    }
    public void set(int tinggi) 
    {
        this.tinggi = tinggi ;    
    }
    public int getjari()
    {
        return jari;
    }
    public int gettinggi()
    {
        return tinggi;
    }
    public double HitungVolume ()
    {
        double volume;
        volume = (jari * jari * tinggi)/3;
        return volume ;
                
    }
}