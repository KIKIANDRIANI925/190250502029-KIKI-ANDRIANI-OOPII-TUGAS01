/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lopping;

/**
 *
 * @author kiki
 */
public class Kubus {
      private int sisi;
    
    public void setsisi (int sisi)
    {
        this.sisi = sisi;
    }
    public int getsisi()
    {
        return sisi;
    }
    public double HitungLuas()
    {
        double luas;
        luas = 6*sisi*sisi;
        return luas;
       
    }
    public double HitungVolume ()
    {
        double Volume;
        Volume = sisi*sisi*sisi;
        return Volume ;
        
                
    }
    
    
}
