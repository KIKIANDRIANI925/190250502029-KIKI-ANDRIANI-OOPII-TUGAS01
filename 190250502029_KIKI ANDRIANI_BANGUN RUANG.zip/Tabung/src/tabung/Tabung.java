/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tabung;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author kiki
 */
public class Tabung {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        BufferedReader datain = new BufferedReader (new InputStreamReader(System.in));
        proses_tabung tabung = new proses_tabung();
        try
        {
            System.out.println("masukkan nilai tinggi :");
            String a = datain.readLine();
            tabung.settinggi(Integer.parseInt(a));
            
            System.out.println("masukkan nilai jari-jari :");
            String r = datain.readLine();
            tabung.setjari(Integer.parseInt(r));
            
            System.out.println("tinggi tabung ="+tabung.gettinggi());
            System.out.println("jari tabung ="+tabung.getjari());
            System.out.println("luas tabung ="+tabung.HitungLuasAlas());
            System.out.println("volume tabung ="+tabung.Hitungvolume());
            System.out.println("keliling tabung ="+tabung.HitungKeliling());
        }
        catch (IOException e)
       
        {
            System.out.println("program ini error");
        }

    }
        
    
}
