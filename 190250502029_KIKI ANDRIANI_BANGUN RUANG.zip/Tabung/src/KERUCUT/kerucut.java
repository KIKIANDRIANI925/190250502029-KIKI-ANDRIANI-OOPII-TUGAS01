/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KERUCUT;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author kiki
 */
public class kerucut {
    public static void main(String[] args) {
        BufferedReader datain = new BufferedReader (new InputStreamReader(System.in));
        proses_kerucut kerucut = new proses_kerucut();
        try
        {
            System.out.println("masukkan nilai jari-jari :");
            String b = datain.readLine();
            kerucut.setjari(Integer.parseInt(b));
            
            System.out.println("masukkan nilai tinggi :");
            String c = datain.readLine();
            kerucut.set(Integer.parseInt(c));
            
            System.out.println("jari-jari ="+kerucut.getjari());
             System.out.println("tinggi ="+kerucut.gettinggi());
             System.out.println("volume ="+kerucut.HitungVolume());
     
        }
        catch (IOException e)
           
        {
            System.out.println("program ini error");
        }

    }
}
    
