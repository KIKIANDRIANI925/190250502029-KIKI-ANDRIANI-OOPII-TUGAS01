/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KUBUS;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author kiki
 */
public class kubus {
    public static void main(String[] args) {
        BufferedReader datain = new BufferedReader (new InputStreamReader(System.in));
        proses_kubus kubus = new proses_kubus();
        try
        {
            System.out.println("masukkan nilai sisi :");
            String b = datain.readLine();
            kubus.setsisi(Integer.parseInt(b));
              
             System.out.println("sisi ="+kubus.getsisi());
             System.out.println("luas ="+kubus.HitungLuas());
             System.out.println("volume ="+kubus.HitungVolume());
     
        }
        catch (IOException e)
           
        {
            System.out.println("program ini error");
        }
    }
    
}
