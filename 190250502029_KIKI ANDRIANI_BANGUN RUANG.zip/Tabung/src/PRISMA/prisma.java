/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRISMA;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author kiki
 */
public class prisma {
    public static void main(String[] args) {
         BufferedReader datain = new BufferedReader (new InputStreamReader(System.in));
        proses_prisma prisma = new proses_prisma();
        try
        {
            System.out.println("masukkan nilai alas :");
            String x = datain.readLine();
            prisma.setalas(Integer.parseInt(x));
            
            System.out.println("masukkan nilai tinggi :");
            String y = datain.readLine();
            prisma.settinggi(Integer.parseInt(y));
            
            System.out.println("masukkan nilai keliling :");
            String z = datain.readLine();
            prisma.setkeliling(Integer.parseInt(z));
            
            
            System.out.println("alas ="+prisma.getalas());
            System.out.println("keliling="+prisma.getkeliling());
            System.out.println("tinggi ="+prisma.gettinggi());
            System.out.println("luas ="+prisma.HitungLuas());
            System.out.println("volume="+prisma.HitungVolume());
     
        }
        catch (IOException e)
           
        {
            System.out.println("program ini error");
        }

    }
}
    
