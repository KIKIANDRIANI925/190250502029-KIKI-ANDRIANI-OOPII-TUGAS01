/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LIMAS;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author kiki
 */
public class limas {
    public static void main(String[] args) {
        BufferedReader datain = new BufferedReader (new InputStreamReader(System.in));
        proses_limas limas = new proses_limas();
        try
        {
            System.out.println("masukkan nilai luas :");
            String x = datain.readLine();
            limas.setLuas(Integer.parseInt(x));
            
            System.out.println("masukkan nilai Tinggi :");
            String y = datain.readLine();
            limas.setTinggi(Integer.parseInt(y));
            
            System.out.println("luas ="+limas.getluas());
            System.out.println("Tinggi="+limas.getTinggi());
            System.out.println("volume ="+limas.HitungVolume());
     
        }
        catch (IOException e)
           
        {
            System.out.println("program ini error");
        }

    }
}
