/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LIMAS;

/**
 *
 * @author kiki
 */
public class proses_limas {
    private int luas ;
    private int tinggi;
    
    public void setLuas(int Luas)
    {
     this.luas = luas;   
    }
    public void setTinggi(int Tinggi)
    {
        this.tinggi = luas ;
    }
    public int getluas()
    {
        return luas;
    }
    public int getTinggi()
    {
        return tinggi;
    }
    public double HitungVolume()
    {
        double volume;
        volume= luas*tinggi*1/3;
        return volume;
    }
}
    
