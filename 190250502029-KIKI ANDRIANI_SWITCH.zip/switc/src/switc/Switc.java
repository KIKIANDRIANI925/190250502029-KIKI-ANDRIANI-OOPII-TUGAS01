/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package switc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author kiki
 */
public class Switc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String pilih; 
        Scanner  Scan = new Scanner(System.in);
        BufferedReader datain = new BufferedReader (new InputStreamReader(System.in));
        prisma prisma = new prisma();
        kerucut kerucut = new kerucut();
        kubus kubus = new kubus();
        limas limas = new limas();
        tabung tabung = new tabung();
         try{
             
             System.out.println("SELAMAT DATANG DI PROGRAM BANGUN DATAR");
             System.out.println("1. hitung prisma");
             System.out.println("2. hitung kerucut");
             System.out.println("3. hitung kubus");
             System.out.println("4. hitung limas");
             System.out.println("5. hitung tabung");
             pilih = Scan.nextLine();
             switch (1){
                 case (1):
                     System.out.println("Anda menghitung prisma");
                     System.out.println("masukan nilai alas");
                     String y = datain.readLine();
                     prisma.settinggi(Integer.parseInt(y));
                     
                     System.out.println("masukkan nilai keliling :");
                     String z = datain.readLine();
                     prisma.setkeliling(Integer.parseInt(z));
            
                     System.out.println("alas ="+prisma.getalas());
                     System.out.println("keliling="+prisma.getkeliling());
                     System.out.println("tinggi ="+prisma.gettinggi());
                     System.out.println("luas ="+prisma.HitungLuas());
                     System.out.println("volume="+prisma.HitungVolume());
                     break;
                 
                 case (2):
                      System.out.println("Anda menghitung kerucut");
                      System.out.println("masukkan nilai jari-jari :");
                      String b = datain.readLine();
                      kerucut.setjari(Integer.parseInt(b));
            
                      System.out.println("masukkan nilai tinggi :");
                      String c = datain.readLine();
                      kerucut.set(Integer.parseInt(c));
            
                      System.out.println("jari-jari ="+kerucut.getjari());
                      System.out.println("tinggi ="+kerucut.gettinggi());
                      System.out.println("volume ="+kerucut.HitungVolume());
                      break;
                      
                 case (3):
                      System.out.println("Anda menghitung kubus");
                      System.out.println("masukkan nilai sisi :");
                      String k = datain.readLine();
                      kubus.setsisi(Integer.parseInt(k));
              
                      System.out.println("sisi ="+kubus.getsisi());
                      System.out.println("luas ="+kubus.HitungLuas());
                      System.out.println("volume ="+kubus.HitungVolume());
                      break;
                      
                  case(4):
                      System.out.println(" Anda Menghitung limas");
                      System.out.println("masukkan nilai luas :");
                      String x = datain.readLine();
                      limas.setLuas(Integer.parseInt(x));
                      
                      System.out.println("masukkan nilai Tinggi :");
                      String w = datain.readLine();
                      limas.setTinggi(Integer.parseInt(w));
            
                      System.out.println("luas ="+limas.getluas());
                      System.out.println("Tinggi="+limas.getTinggi());
                      System.out.println("volume ="+limas.HitungVolume());
                      break;
                      
                  case (5):
                      System.out.println("Anda Menghitung tabung");
                      System.out.println("masukkan nilai tinggi :");
                      String a = datain.readLine();
                      tabung.settinggi(Integer.parseInt(a));
            
                      System.out.println("masukkan nilai jari-jari :");
                      String r = datain.readLine();
                      tabung.setjari(Integer.parseInt(r));
            
                      System.out.println("tinggi tabung ="+tabung.gettinggi());
                      System.out.println("jari tabung ="+tabung.getjari());
                      System.out.println("luas tabung ="+tabung.HitungLuasAlas());
                      System.out.println("volume tabung ="+tabung.Hitungvolume());
                      System.out.println("keliling tabung ="+tabung.HitungKeliling());
                      break;          
             }
              }
              catch (IOException e)
              {
        
             
    }
    }
    
}
