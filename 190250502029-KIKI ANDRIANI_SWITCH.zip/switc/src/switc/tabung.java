/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package switc;

/**
 *
 * @author kiki
 */
public class tabung {
     private int tinggi;
    private int jari ;
    
    public void settinggi(int tinggi)
    {
            this.tinggi = tinggi ;
    }
    public void setjari(int jari)
    {
            this.jari = jari ;
    }
     
    public int gettinggi()
    {
        return tinggi;
    }
    public int getjari()
    {
        return jari;
    }
    public double HitungLuasAlas()
    {
        double luas;
        luas = 3.14*(jari*jari);
        return luas;
    }
    public double Hitungvolume()
    {
        double volume;
        volume = 3.14*jari*2*tinggi;
        return volume;
    }
     public double HitungKeliling()
    {
        double keliling;
        keliling = 2*3.14*jari;
        return keliling;
    }
    
}
