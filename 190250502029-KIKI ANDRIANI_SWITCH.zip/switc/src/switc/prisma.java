/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package switc;

/**
 *
 * @author kiki
 */
public class prisma {
    private int alas ;
    private int tinggi;
    private int keliling;
    
    public void setalas (int alas)
    {
        this.alas = alas ;
    }
      public void settinggi (int tinggi)
    {
        this.tinggi = tinggi ;
    }
      public void setkeliling (int keliling)
    {
        this.keliling = keliling ;
    }
      public int getalas()
      {
          return alas;
      }
       public int gettinggi()
      {
          return tinggi;
      }
        public int getkeliling()
      {
          return keliling; 
      }
        public double HitungVolume ()
        {
                double volume ;
                volume = (alas*tinggi)/2*tinggi ;
                return volume;
        }
        
        public double HitungLuas ()
        {
            double luas;
            luas = (2*alas)+(keliling*tinggi);
            return luas;
        }
    
}
  
